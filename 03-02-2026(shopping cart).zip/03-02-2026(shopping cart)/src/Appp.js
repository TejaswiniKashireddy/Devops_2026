src/App.js
----------------
import React from "react";
import Cart from "./Cart";  // Import Cart component

function App() {
  return (
    <div>
      <Cart />  {/* Use Cart component */}
    </div>
  );
}

export default App;